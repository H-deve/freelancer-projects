!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <title>My CodeIgniter App</title>
</head>
<body>
 
  <header>
    <nav>
      <ul>
        <li>My menu item</li>
      </ul>
    </nav>
  </header>
 
  <section>
    <p>Here is where i will put the text</p>
  </section>
 
  <aside> 
    <p>Here is a sidebar</p>
  </aside>
 
  <footer>
    <p>Copyright 2009 My CodeIgniter app</p>
  </footer>
 
</body>
</html>
<footer>
    <p>Copyright 2009 My CodeIgniter app</p>
  </footer>
</body>
</html>
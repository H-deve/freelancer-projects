<?php if(!defined('BASEPATH')) exit('No direct script access allowed');
 
class Map_co extends CI_Controller{
    public function index(){
    	
        $this->load->view('Map_view');
    }
}
?>
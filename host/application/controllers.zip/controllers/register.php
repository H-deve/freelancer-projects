<?php

class register extends CI_Controller{


public function r_token(){

$this->load->model("register_model");


if(isset($_POST["Token"])){

$token=$_POST["Token"];


}
}


}





?>